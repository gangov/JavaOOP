import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class reflection = Reflection.class;
//        System.out.println(reflection);
////        System.out.println(reflection.getSuperclass());
////        for (Class anInterface : reflection.getInterfaces()) {
////            System.out.println(anInterface);
////        }
////        Object reflectionObj = reflection.getDeclaredConstructor().newInstance();
////        System.out.println(reflectionObj);

        Method[] declaredMethods = reflection.getDeclaredMethods();

        declaredMethods = Arrays.stream(declaredMethods).sorted(Comparator.comparing(Method::getName)).toArray(Method[]::new);

        for (Method declaredMethod : declaredMethods) {
            String name = declaredMethod.getName();

            if (name.contains("get")) {
                System.out.println(String.format("%s will return class %s", name, declaredMethod.getReturnType().getName()));
            }

        }
        for (Method declaredMethod : declaredMethods) {
            String name = declaredMethod.getName();

            if (name.contains("set")) {

                System.out.print(String.format("%s and will set field of class ", name));

                Parameter[] parameterTypes = declaredMethod.getParameters();

                for (int i = 0; i < parameterTypes.length; i++) {
                    System.out.print(parameterTypes[i].getType().getName() + " ");
                }
                System.out.println();
            }

        }


    }
}
